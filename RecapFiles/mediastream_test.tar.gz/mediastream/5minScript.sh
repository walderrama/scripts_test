#!/bin/bash

tail -n 3 /var/log/syslog
printf '%s\n' --------------------`date '+%H:%M-%d%m%Y'`
df -h /mediastream
printf '%s\n' --------------------`date '+%H:%M-%d%m%Y'`
last
printf '%s\n' --------------------`date '+%H:%M-%d%m%Y'`

